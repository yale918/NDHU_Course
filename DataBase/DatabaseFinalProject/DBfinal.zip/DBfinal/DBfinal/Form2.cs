﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;


namespace DBfinal
{
    public partial class Form2 : Form
    {
        private System.Windows.Forms.BindingSource bindingSource1;
        private SqlDataAdapter dataAdapter = new SqlDataAdapter();
        public Form2()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, System.EventArgs e)
        {
            dataGridView1.DataSource = bindingSource1;

        }


        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            string connectString = "Data Source =127.0.0.1; Initial Catalog=410335014; Integrated Security = SSPI";
            SqlConnection con = new SqlConnection(connectString);
            con.Open();
            string sqlSelect = "select * from Class";
            SqlCommand cmd = new SqlCommand(sqlSelect, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                comboBox1.Items.Add(reader["CID"].ToString().Trim()+"    "+ reader["Teacher"].ToString().Trim()+"  "+ reader["CName"].ToString().Trim());
            }
            
        }

        
        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
           
            String s = comboBox1.Text.Trim();//課程代碼
            
            string connectstring = "Data Source =127.0.0.1; Initial Catalog=410335014; Integrated Security = SSPI";
            SqlConnection cnn = new SqlConnection(connectstring);
            cnn.Open();
            string sqlSelect = "select CID,PID,NNumber,VNum,ISBN from RResault where CID=@s";
            SqlCommand command = new SqlCommand(sqlSelect, cnn);
            command.Parameters.Add("@s", s.Substring(0, 10).Trim());
            DataTable QQ = new DataTable();
            SqlDataReader reader = command.ExecuteReader();
            if (reader.HasRows)
            {
                QQ.Load(reader);
                dataGridView1.DataSource = QQ;

            }
            cnn.Close();
        }
    }
}
