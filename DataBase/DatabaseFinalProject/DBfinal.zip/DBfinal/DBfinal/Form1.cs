﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DBfinal
{
    public partial class Form1 : Form
    {
        private SqlDataAdapter dataAdapter = new SqlDataAdapter();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            string connetionString = "Data Source=127.0.0.1; Initial Catalog=410335014; Integrated Security = SSPI";
            SqlConnection con = new SqlConnection(connetionString);

            try
            {
                con.Open();
                //MessageBox.Show("Connection Open ! ");
                con.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Can not open connection ! ");
            }

            con.Open();
            string select = "select SNum from Student where SNum=@SNum";

            SqlCommand cmd = new SqlCommand(select, con);
            cmd.Parameters.Add("@SNum", SqlDbType.Int).Value = textBox1.Text.Trim();
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {

                Form2 mainform = new Form2();
                mainform.Show(this);
            }
        }
        private void button2_MouseClick(object sender, MouseEventArgs e)
        {
            Form3 write = new Form3();
            write.Show(this);
        }
    }
}
