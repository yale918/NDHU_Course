﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DBfinal
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            string connectString = "Data Source =127.0.0.1; Initial Catalog=410335014; Integrated Security = SSPI";
            SqlConnection con = new SqlConnection(connectString);

            try
            {
                con.Open();
                //MessageBox.Show("Connection Open ! ");
                con.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Can not open connection ! ");
            }


            con.Open();
            string sqlInsert = "insert into Student (SNum,SYear,SName) values (@SNum,@SYear,@SName)";
            SqlCommand cmd = new SqlCommand(sqlInsert, con);

            cmd.Parameters.Add("@SNum", textBox1.Text);
            cmd.Parameters.Add("@SYear", textBox2.Text);
            cmd.Parameters.Add("@SName", textBox3.Text);
            cmd.ExecuteNonQuery();


            cmd.Cancel();
            con.Close();
            con.Dispose();

            this.Close();
        }
    }
}

